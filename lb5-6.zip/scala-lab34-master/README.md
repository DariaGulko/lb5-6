# scala-lab34
Lab 3-4 (scala.actors)
